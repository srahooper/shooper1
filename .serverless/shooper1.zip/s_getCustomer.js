
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'srahooper',
  applicationName: 'shooper1',
  appUid: 'thWzvGbD4Hj9tpLlVt',
  orgUid: 'dec9b66f-dd1a-4553-87b7-455a9c685b7d',
  deploymentUid: '4535b2cd-5c15-4792-b7a4-a1c21d8071b0',
  serviceName: 'shooper1',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'shooper1-dev-getCustomer', timeout: 6 };

try {
  const userHandler = require('./getCustomer.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getCustomer, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}